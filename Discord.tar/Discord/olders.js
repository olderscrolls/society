//A Botot OlderS készitette, Felhasználása semmilyen formában nem engedélyezett.
//created by OlderS
 const Discord = require('discord.js');
 const client = new Discord.Client();
 const { Client, Attachment } = require('discord.js');
 const config = require("./config.json");
 client.login(config.token);

client.on('ready', () => {
 console.log(`Bejelentkezve ${client.user.tag}!`);
 client.user.setStatus('available') // 'available', 'idle', 'dnd', vagy 'invisible'
     client.user.setPresence({
         game: {
             name: 'Segitségért ird !help',
             type: 0
         }
     });
 });


 //Parancsok
 client.on('message', msg => {
   if (msg.content === '!ts'){

   if(msg.member.roles.find(role => role.name === "-Sigma-") || msg.member.roles.find(role => role.name === "-Hunter-") || msg.member.roles.find(role => role.name === "-Lead Hunter-") || msg.member.roles.find(role => role.name === "=Warrior=") || msg.member.roles.find(role => role.name === "=Lead Warrior=") || msg.member.roles.find(role => role.name === "=Gamma=") || msg.member.roles.find(role => role.name === "=Beta=") || msg.member.roles.find(role => role.name === "=Alpha=")){
   msg.channel.send('Teamspeak Cimünk: ts3.agcgamer.com Jelszó: agc789');
   }else{
   msg.channel.send('Nincs elég jogod a parancs használatához');
   }
 }});


client.on('message', msg => {
  if (msg.content === '!parancsok') {
  msg.channel.send('!weblap, !ts, !rip, !streamerek');
}
});

client.on('message', msg => {
  if (msg.content === '!help') {
  msg.channel.send('Ha segitségre van szükséged keress fel egy support/admint -ot (Gamma/Beta rang), Parancsokért !parancsok"');
}
});

client.on('message', msg => {
 if (msg.content === '!weblap') {
 msg.channel.send('http://agcgamer.com/');
 }
 });



  client.on('message', msg => {
   if (msg.content === '!streamerek') {
   msg.channel.send('RaZ - https://www.twitch.tv/raz_channel');
   msg.channel.send('OlderS - https://www.twitch.tv/olderscrolls');
   msg.channel.send('VenTureSTM - https://www.twitch.tv/venturestm');
   msg.channel.send('OscarPapa - https://www.twitch.tv/oscarpapar6s');
   msg.channel.send('Stampow - https://www.twitch.tv/stampow');
   msg.channel.send('Vityesz - https://www.twitch.tv/vityeszur29');
   }
   });


   client.on('message', msg => {
    if (msg.content === '!bot') {
    msg.channel.send("A botot OlderS Készitette");
    }
    });


//Gifes parancsok

  client.on('message', message => {

      if (message.content === '!rip') {
          const attachment = new Attachment('https://i.imgur.com/w3duR07.png');
          message.channel.send(attachment);
      }
  });

  client.on('message', message => {
      if (message.content === '!zombie') {
          const attachment = new Attachment('https://i.imgur.com/Wtn9glf.gif');
          message.channel.send(attachment);
      }
  });


  //Üdvözlő

client.on('guildMemberAdd', member => {

  const channel = member.guild.channels.find(ch => ch.name === 'be-ki-toppanó');
  if (!channel) return;
  channel.send(`Üdvözlet az AGC Discord Szerverén, ${member}`);
});

  //Távozást jelző

client.on('guildMemberRemove', member => {
  const channel = member.guild.channels.find(ch => ch.name === 'be-ki-toppanó');
  if (!channel) return;
  channel.send(` ${member} , Távozott köreinkből!`);
});
